import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ConsoleApiService } from './console-api/console-api.service';

@NgModule({
  declarations: [],
  providers: [ConsoleApiService],
  imports: [
    CommonModule,
    HttpClientModule,
  ],
})
export class ClientApisModule { }
