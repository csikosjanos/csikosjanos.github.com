import { HttpClientModule } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';

import { ConsoleApiService } from './console-api.service';

describe('ConsoleApiService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports: [HttpClientModule],
  }));

  it('should be created', () => {
    const service: ConsoleApiService = TestBed.get(ConsoleApiService);
    expect(service).toBeTruthy();
  });
});
