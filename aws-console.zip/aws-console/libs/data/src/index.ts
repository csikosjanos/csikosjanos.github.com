export * from './lib/ec2.interface';
