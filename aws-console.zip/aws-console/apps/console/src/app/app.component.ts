import { Component } from '@angular/core';

@Component({
  selector: 'aws-console-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {}
