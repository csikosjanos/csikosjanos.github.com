import { AfterViewInit, Component, ViewChild } from '@angular/core';
import { MatPaginator, MatSort } from '@angular/material';
import { ConsoleApiService } from '@aws-console/apis';
import { Ec2 } from '@aws-console/data';
import { Ec2ListDataSource } from './ec2-list-datasource';

@Component({
  selector: 'aws-console-ec2-list',
  templateUrl: './ec2-list.component.html',
  styleUrls: ['./ec2-list.component.css']
})
export class Ec2ListComponent implements AfterViewInit {
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  dataSource: Ec2ListDataSource;

  /** Columns displayed in the table. Columns IDs can be added, removed, or reordered. */
  displayedColumns = ['id', 'name', 'type', 'state', 'az', 'publicIP', 'privateIP'];

  constructor(private consoleApiService: ConsoleApiService) {}

  ngAfterViewInit() {
    this.consoleApiService.getEc2s().subscribe((ec2s: Ec2[]) => {
      this.dataSource = new Ec2ListDataSource(this.paginator, this.sort);
      this.dataSource.data = ec2s;
    });
  }
}
