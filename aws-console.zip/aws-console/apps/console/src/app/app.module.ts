import { NgModule } from '@angular/core';
import { MatPaginatorModule, MatSortModule, MatTableModule } from '@angular/material';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ClientApisModule } from '@aws-console/apis';

import { AppComponent } from './app.component';
import { Ec2ListComponent } from './ec2-list/ec2-list.component';

@NgModule({
  declarations: [
    AppComponent,
    Ec2ListComponent,
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    ClientApisModule,
  ],
  providers: [],
  bootstrap: [ AppComponent ]
})
export class AppModule {}
