import { Test, TestingModule } from '@nestjs/testing';
import { Ec2sService } from './ec2s.service';

describe('Ec2sService', () => {
  let service: Ec2sService;
  
  beforeAll(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [Ec2sService],
    }).compile();

    service = module.get<Ec2sService>(Ec2sService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  describe('findAll()', function() {
    it('should be defined', () => {
      expect(service.findAll).toBeDefined();
    });

    it('should return mock list of EC2 instances', () => {
      const expectedInstances = [
        {
          id: 'a-123456abcd',
          name: 'first EC2 instance',
          type: 't2.medium',
          state: 'running',
          az: 'us-east-1b',
          publicIP: '54.210.167.204',
          privateIP: '10.20.30.40',
        },
        {
          id: 'b-123456abcd',
          name: 'second EC2 instance',
          type: 't2.small',
          state: 'running',
          az: 'us-east-1b',
          publicIP: '54.210.167.206',
          privateIP: '10.20.30.41',
        },
        {
          id: 'c-123456abcd',
          name: 'third EC2 instance',
          type: 't2.large',
          state: 'running',
          az: 'us-east-1b',
          publicIP: '54.210.167.205',
          privateIP: '10.20.30.42',
        },
        {
          id: 'd-123456abcd',
          name: 'fourth EC2 instance',
          type: 't2.medium',
          state: 'running',
          az: 'us-east-1b',
          publicIP: '54.210.167.203',
          privateIP: '10.20.30.43',
        },
        {
          id: 'e-123456abcd',
          name: 'fifth EC2 instance',
          type: 't2.large',
          state: 'running',
          az: 'us-east-1b',
          publicIP: '54.210.167.202',
          privateIP: '10.20.30.44',
        },
        {
          id: 'f-123456abcd',
          name: 'sixth EC2 instance',
          type: 't2.small',
          state: 'running',
          az: 'us-east-1b',
          publicIP: '54.210.167.201',
          privateIP: '10.20.30.45',
        },
      ];
      expect(service.findAll()).toEqual(expectedInstances);
    });
  });
});
