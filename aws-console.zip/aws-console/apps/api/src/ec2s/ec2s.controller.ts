import { Ec2 } from '@aws-console/data';
import { Controller, Get } from '@nestjs/common';
import { Ec2sService } from './ec2s.service';

@Controller('ec2s')
export class Ec2sController {
  constructor(private readonly ec2sService: Ec2sService) {}

  @Get()
  async findAll(): Promise<Ec2[]> {
    return this.ec2sService.findAll();
  }
}
