import { Module } from '@nestjs/common';
import { Ec2sModule } from '../ec2s/ec2s.module';

import { AppController } from './app.controller';
import { AppService } from './app.service';

@Module({
  imports: [Ec2sModule],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
