import { ec2Table, ec2TableHeads, getHeading2, getTitle, paginatorLabel } from '../support/app.po';

describe('Hello Nx', () => {
  beforeEach(() => {
    cy.fixture('ec2s').as('EC2s').then(() => {
      cy.server();
      cy.route('GET', '/api/ec2s', '@EC2s');
      cy.visit('/');
    });
  });

  it('should display the title', () => {
    getTitle().contains('AWS Console');
  });

  it('should display second level heading', () => {
    getHeading2().contains('EC2 Instances');
  });

  describe('Table with EC2 instances', () => {
    it('should be display', () => {
      ec2Table().should('be.visible');
    });

    it('should be sortable', () => {
      ec2Table().should('have.attr', 'matSort');
    });

    it('should have column names as id, name, type, state, az, publicIP and privateIP', () => {
      ['Id', 'Name', 'Type', 'State', 'Az', 'Publicip', 'Privateip'].forEach((item) => {
        ec2TableHeads().contains(item);
      });
    });

    it('should display data', () => {
      paginatorLabel().contains('1 - 5 of 6');
    });
  });
});
