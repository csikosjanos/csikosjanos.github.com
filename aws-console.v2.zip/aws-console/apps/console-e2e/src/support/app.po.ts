export const getTitle = () => cy.get('h1');
export const getHeading2 = () => cy.get('h2');
export const ec2Table = () => cy.get('table');
export const ec2TableHeads = () => cy.get('th button');
export const paginatorLabel = () => cy.get('div.mat-paginator-range-label');
