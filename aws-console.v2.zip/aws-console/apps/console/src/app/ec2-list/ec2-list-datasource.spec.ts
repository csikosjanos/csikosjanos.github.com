import { MatPaginator, MatSort } from '@angular/material';
import { Ec2ListDataSource } from './ec2-list-datasource';

describe('EC2 list datasource', () => {
  const mockPaginator = {};
  const mockSort = new MatSort();

  let ds: Ec2ListDataSource;

  beforeEach(() => {
    ds = new Ec2ListDataSource(mockPaginator as MatPaginator, mockSort);
  });

  describe('compare()', () => {
    it('should compare two value for sorting with direction given', () => {
      //string
      expect(ds.compare('1', '2', true)).toBe(-1);
      expect(ds.compare('1', '2', false)).toBe(1);
      expect(ds.compare('2', '1', true)).toBe(1);
      expect(ds.compare('2', '1', false)).toBe(-1);

      //integer
      expect(ds.compare(1, 2, true)).toBe(-1);
      expect(ds.compare(1, 2, false)).toBe(1);
      expect(ds.compare(2, 1, true)).toBe(1);
      expect(ds.compare(2, 1, false)).toBe(-1);
    });
  });
});
