import { HttpClientModule } from '@angular/common/http';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HAMMER_LOADER } from '@angular/platform-browser';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { MatPaginatorModule, MatSortModule, MatTableModule } from '@angular/material';
import { ConsoleApiService } from '@aws-console/apis';
import { ec2s as mockEc2s } from '@aws-console/data';

import { Ec2ListComponent } from './ec2-list.component';

class MockConsoleApiService {
  getEc2s = jest.fn().mockReturnValue({
    subscribe: (callback) => callback(mockEc2s)
  });
}

const mockConsoleApiService = new MockConsoleApiService();

describe('Ec2ListComponent', () => {
  let component: Ec2ListComponent;
  let fixture: ComponentFixture<Ec2ListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Ec2ListComponent ],
      imports: [
        HttpClientModule,
        NoopAnimationsModule,
        MatPaginatorModule,
        MatSortModule,
        MatTableModule
      ],
      providers: [
        { provide: ConsoleApiService, useValue: mockConsoleApiService },
        { provide: HAMMER_LOADER, useValue: () => new Promise(() => {}) },
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Ec2ListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should compile', () => {
    expect(component).toBeTruthy();
  });

  it('should display table columns', () => {
    const expectedDisplayedColumns = [
      'id',
      'name',
      'type',
      'state',
      'az',
      'publicIP',
      'privateIP'
    ];

    expect(component.displayedColumns).toEqual(expectedDisplayedColumns);
  });

  it('should request the EC2 instances after the view initialised', () => {
    component.ngOnInit();
    expect(mockConsoleApiService.getEc2s).toHaveBeenCalled();
  });

  it('should assign the retrieved data to the data source of the table', () => {
    component.ngOnInit();
    expect(component.dataSource.data).toEqual(mockEc2s);
  });
});
