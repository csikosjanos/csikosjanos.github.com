import { Ec2 } from '@aws-console/data';
import { Test, TestingModule } from '@nestjs/testing';
import { Ec2sController } from './ec2s.controller';
import { Ec2sService } from './ec2s.service';

describe('Ec2s Controller', () => {
  let module: TestingModule;
  let controller: Ec2sController;
  let service: Ec2sService;
  
  beforeAll(async () => {
    module = await Test.createTestingModule({
      controllers: [Ec2sController],
      providers: [Ec2sService],
    }).compile();
    controller = module.get<Ec2sController>(Ec2sController);
    service = module.get<Ec2sService>(Ec2sService);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });

  describe('findAll()', () => {
    it('should return an array of EC2 instances', async () => {
      const result: Ec2[] = [
        {
          id: 'dummy',
          name: 'first EC2 instance',
          type: 't2.medium',
          state: 'running',
          az: 'us-east-1b',
          publicIP: '54.210.167.204',
          privateIP: '10.20.30.40',
        }
      ];

      jest.spyOn(service, 'findAll').mockImplementation(() => result);

      expect(await controller.findAll()).toBe(result);
    });
  });
});
