import { Module } from '@nestjs/common';
import { Ec2sController } from './ec2s.controller';
import { Ec2sService } from './ec2s.service';

@Module({
  controllers: [Ec2sController],
  providers: [Ec2sService]
})
export class Ec2sModule {}
