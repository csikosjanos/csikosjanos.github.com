import { Injectable } from '@nestjs/common';
import { Ec2, ec2s } from '@aws-console/data';

@Injectable()
export class Ec2sService {
  private readonly ec2s = ec2s;

  findAll(): Ec2[] {
    return this.ec2s;
  }
}
