import { ec2s as expectedInstances } from '@aws-console/data';
import { Test, TestingModule } from '@nestjs/testing';
import { Ec2sService } from './ec2s.service';

describe('Ec2sService', () => {
  let service: Ec2sService;
  
  beforeAll(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [Ec2sService],
    }).compile();

    service = module.get<Ec2sService>(Ec2sService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  describe('findAll()', function() {
    it('should be defined', () => {
      expect(service.findAll).toBeDefined();
    });

    it('should return mock list of EC2 instances', () => {
      expect(service.findAll()).toEqual(expectedInstances);
    });
  });
});
