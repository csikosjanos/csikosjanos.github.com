import { HttpClient } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';

import { ConsoleApiService } from './console-api.service';
import { ec2s as expectedEc2s } from '@aws-console/data';
import { of as observableOf } from 'rxjs';

describe('ConsoleApiService', () => {
  let service: ConsoleApiService;
  const mockHttpClient = {
    get: jest.fn().mockReturnValue(observableOf(expectedEc2s)),
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        ConsoleApiService,
        {provide: HttpClient, useValue: mockHttpClient}
      ]
    });

    service = TestBed.get(ConsoleApiService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('getEc2s()',() => {
    it('should be called with the correct url', () => {
      service.getEc2s();
      expect(mockHttpClient.get).toHaveBeenCalledWith('http://localhost:3333/api/ec2s');
    });

    it('should return with a stream of EC2s',() => {
      service.getEc2s().subscribe(ec2s => {
        expect(ec2s).toEqual(expectedEc2s)
      });
    });
  });
});
