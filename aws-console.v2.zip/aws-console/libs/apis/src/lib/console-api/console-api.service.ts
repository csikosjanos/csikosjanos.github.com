import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Ec2 } from '@aws-console/data';
import { Observable } from 'rxjs';

export interface EndpointConfig {
  url: string;
  port: number;
}

@Injectable({
  providedIn: 'root'
})
export class ConsoleApiService {
  constructor(private http: HttpClient) { }

  getEc2s(config: EndpointConfig = {url: 'http://localhost', port: 3333}): Observable<Ec2[]> {
    const url = `${config.url}:${config.port}/api/ec2s`;
    return this.http.get<Ec2[]>(url);
  }
}
