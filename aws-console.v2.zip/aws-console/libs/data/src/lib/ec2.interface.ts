export interface Ec2 {
  id: string;
  name: string;
  type: string;
  state: string;
  az: string;
  publicIP: string;
  privateIP: string;
}
